function DOA = UnitaryEsprit(x, P, mode)
%********************************************************
% This function calculates Unitary TLS-ESPRIT estimator
% for uniform linear array.
%
% Inputs
%    R_hat    array output covariance matrix
%    noSorc   estimated number of sources
%    mode     1:LS   2:TLS
%
% Output
%    doa      estimated angles in degrees
%             and 'doa' is a column vector
%********************************************************

[M, N] = size(x);

%----------------unitary transformation----------------
k = fix(M/2);

if k*2 == M           % K : even
    
    Ik = eye(k); Jk=fliplr(Ik);
    Qn = [Ik, 1j*Ik; Jk, -1j*Jk]/sqrt(2);
    
    kk=k-1; Ikk=eye(kk); Jkk=fliplr(Ikk); Zr=zeros(kk,1);
    Qn1 = [Ikk, Zr, 1j*Ikk; Zr', sqrt(2), Zr'; Jkk, Zr, -1j*Jkk]/sqrt(2);
    
else                            % K : odd
    
    Ik=eye(k); Jk=fliplr(Ik); Zr=zeros(k,1);
    Qn=[Ik, Zr, 1j*Ik; Zr', sqrt(2), Zr'; Jk, Zr, -1j*Jk]/sqrt(2);
    Qn1=[Ik, 1j*Ik; Jk, -1j*Jk]/sqrt(2);
    
end
%----------------------------------------------------

%-----------calculation of K1 and K2-----------------
Js2 = [zeros(M-1,1), eye(M-1)];
Zw  = Qn1'*Js2*Qn;
K1  = real(Zw);
K2  = imag(Zw);

%-----------finding Us-------------
R_hat = 1/N * x * x';
S_hat = real(Qn'*R_hat*Qn);
[U, ~] = svd(S_hat);
Us = U(:, 1:P);

Ex = K1*Us;
Ey = K2*Us;

if strcmp(mode,'TLS')   
   %-----TLS-ESPRIT---------
    Exy = [Ex, Ey];
    E_xys = Exy'*Exy;
    
    [Us_xy, ~] = svd(E_xys);
    
    Gx = Us_xy(1:P, P+1:P*2);
    Gy = Us_xy(P+1:P*2, P+1:P*2);
    
    Psi = -Gx/Gy;
    
elseif strcmp(mode,'LS')   
   %----LS-ESPRIT----
    Psi = Ex\Ey;
end

%-----------DOA Estimation------------
D = real(eig(Psi));
phi = 2*atan(D);

DOA = asin(phi/pi) * 180/pi;
DOA = sort(DOA);
