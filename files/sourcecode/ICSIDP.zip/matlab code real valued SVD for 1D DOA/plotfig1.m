%plot figure 1
%fig1

width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
msz = 6;       % MarkerSize


figure
grid on 
box on
hold on;
plot(SNR, RMSE1.^0.5, '-+','color', [0.5 0.1 0.48], 'markersize', msz, 'linewidth', lw);
plot(SNR, RMSE2.^0.5, 'c-*', 'markersize', msz, 'linewidth', lw);
% semilogy(SNR, RMSE2.^0.5, '-o', 'markersize', mz, 'linewidth', 2); 
plot(SNR, RMSE3.^0.5, '->','color', [0.31 0.4 0.58], 'markersize', msz, 'linewidth', lw);

plot(SNR, RMSE5.^0.5, 'g-d', 'markersize', msz, 'linewidth',lw)
plot(SNR, RMSE_new1.^0.5, 'm-^', 'markersize', msz, 'linewidth',lw)
plot(SNR, RMSE_U_ESPRIT.^0.5, '-s','color', [0.4 0.6 0.7], 'markersize', msz, 'linewidth', lw)

plot(SNR, CRB.^0.5, 'r-',  'markersize', msz, 'linewidth',lw)

grid on
xlabel('SNR (dB)'); ylabel('RMSE (degree)');
% legend('PUMA', 'EPUMA', 'root-MUSIC', 'MODEX', 'MODE', 'UPUMA','CRB');
% legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','PUMA','CRB');
legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC', 'MODE','Nystrom ESPRIT','Unitary ESPRRIT new', 'CRB');


