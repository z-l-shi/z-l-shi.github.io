clc;clear;close all;warning off

%% If you find the code useful, please cite our paper
% C. Qian, L. Huang, M. Cao, H. C. So and J. Xie, "PUMA: An improved realization of MODE for DOA estimation," IEEE Transactions on Aerospace and Electronic Systems, vol. 53, no. 5, pp. 2128-2139, 2017.
% C. Qian, L. Huang, N. D. Sidiropoulos and H. C. So, "Enhanced PUMA for direction-of-arrival estimation and its performance analysis," IEEE Transactions on Signal Processing, vol.64, no.16, pp.4127-4137, 2016. 
%%

% M = 10;
N = 50;
% DOA = [-5, 2, 12];
DOA = [8     35];
K = length(DOA);
% SNR = linspace(-12,6,12);
SNR=10;
Cubic=6:1:20;
% Cubic=12:1:30;
nT = 10;
P=length(Cubic);
Runtime0=zeros(P,1);  
Runtime1=zeros(P,1);  
Runtime2=zeros(P,1); 
Runtime3=zeros(P,1); 
Runtime4=zeros(P,1);  
Runtime5=zeros(P,1); 
% Runtime6=zeros(P,1); 


for k_cubic = 1:length(Cubic)
    M=Cubic(k_cubic);
    snr = SNR ;

    for iT = 1:nT
        
        if rem(iT,nT/2) == 0
            fprintf( 'n = %d, Trials = %d, total = %d\n',...
                k_cubic, iT, (k_cubic-1)*nT+iT );
        end
        
        x = StatSigGenerate(M, N, DOA, snr*ones(1,K));
%                 x = StatSigGenerate1D(M, N, DOA, snr*ones(1,K));
tic;
        Rxx=x*x';doa1(:,iT)=UnitaryPUMA2tone(Rxx, 4,K);
        s0=toc; Runtime0(k_cubic)=Runtime0(k_cubic)+s0;
        tic;
        doa2(:,iT) = UnitaryEsprit(x, K, 'LS');
        s1=toc;  Runtime1(k_cubic)=Runtime1(k_cubic)+s1;
        tic;
        doa3(:,iT) = rMUSIC(x, K, 'FBSS', 2);
        s2=toc;  Runtime2(k_cubic)=Runtime2(k_cubic)+s2;
        tic;
        [doa4(:,iT),doa5(:,iT)] = MODEX(x, K);
        s3=toc; Runtime3(k_cubic)=Runtime3(k_cubic)+s3;
        Runtime4(k_cubic)=Runtime4(k_cubic)+s3;
%         tic;
%         Rxx=x*x';
% %          wc= UnitaryPUMA(Rxx, 5);
% % %           wc=  PUMAnew(Rxx, 5);
% %          twpi = 2*pi;
% %          check1=twpi*0.5;
% %          derad = pi/180;
% %          
% %           doa6(:,iT)=[asin((abs(wc) /check1))]/derad;
%           
%           doa6(:,iT)=UnitaryPUMA2tone(Rxx, 4,K);
%           s5=toc; Runtime5(k_cubic)=Runtime5(k_cubic)+s5;
    end
    
%     RMSE1(iS) = rmse(doa1, DOA);
%     RMSE2(iS) = rmse(doa2, DOA);
%     RMSE3(iS) = rmse(doa3, DOA);
%     RMSE4(iS) = rmse(doa4, DOA);
%     RMSE5(iS) = rmse(doa5, DOA);
%     RMSE6(iS) = rmse(doa6, DOA);
%     [x, A, R_idl, Rs] = StatSigGenerate(M, N, DOA, snr*ones(1,K));
%     [x, A, R_idl, Rs] = StatSigGenerate1D(M, N, DOA, snr*ones(1,K));
%     CRB(iS) = crbdet_w(A,R_idl,Rs,DOA,N,1)*(180/pi)^2;
    
end
Time_PUMA=Runtime0/(nT);
Time_EPUMA=Runtime1/(nT);
Time_rootMUSIC=Runtime2/(nT);
Time_MODEX=Runtime3/(nT);
Time_MODE=Runtime4/(nT);
Time_UPUMA=Runtime5/(nT);
 
width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
msz = 6;       % MarkerSize
KK=3;
figure
grid on 
box on
plot(Cubic(KK:end), Time_PUMA(KK:end),  '-+','color', [0.5 0.1 0.48], 'markersize', msz, 'linewidth', lw); hold on;
plot(Cubic(KK:end), Time_EPUMA(KK:end), 'c-*', 'markersize', msz, 'linewidth', lw); 
plot(Cubic(KK:end), Time_rootMUSIC(KK:end),'->','color', [0.31 0.4 0.58], 'markersize', msz, 'linewidth', lw);
% semilogy(Cubic(KK:end), Time_MODEX(KK:end), '-*', 'markersize', mz, 'linewidth', 2)
plot(Cubic(KK:end), Time_MODE(KK:end),'g-d', 'markersize', msz, 'linewidth',lw)
% plot(Cubic(KK:end), Time_UPUMA(KK:end), 'r-',  'markersize', msz, 'linewidth',lw)
% semilogy(SNR, CRB.^0.5, 'k', 'linewidth', 2)
grid on
xlabel('M')
ylabel('Runtime (Second)');
legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','CRB');
