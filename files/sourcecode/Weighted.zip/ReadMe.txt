%Readme

% Run "Demo_v1.m" for a demo, which will download a publicly available dataset (around 3MB) and show the usage of WBSLRR_ECCV_verson1.m 

% The expected output of "Demo_v1.m" is in Example_output_of_Demo_v1.m, you can open the fle to take a look.

% "WBSLRR_ECCV_verson1.m" is the main function that solves the WBSLRR problem. 
% You can find the details of the parameters in "WBSLRR_ECCV_verson1.m"


%================= Please kindly cite the following paper if you use the code in your publication=======================
%[1] Shijie Xiao, Mingkui Tan, Dong Xu, "Weighted Block-Sparse Low Rank Representation for Face Clustering in Videos", European Conference on Computer Vision (ECCV), pp. 123-138, 2014
% 
% @inproceedings{Xiao2014WBSLRR,
%   author    = {Shijie Xiao and
%                Mingkui Tan and
%                Dong Xu},
%   title     = {Weighted Block-Sparse Low Rank Representation for Face Clustering
%                in Videos},
%   booktitle = {European Conference on Computer Vision},  
%   year      = {2014},
%   pages     = {123--138},
% }

%This code is from the project page of [1]:     https://sites.google.com/site/xiaoshijiejerry/projec/eccv2014_wbslrr/
%This code is for reseach purpose only.
