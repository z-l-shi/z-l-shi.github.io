function DOA= ESPRIT(xx, m, P)

M = size(x,1);

J1 = [eye(m), zeros(m,M-m)];
J2 = [zeros(m,M-m), eye(m)];

n = size(x, 2);

R = 1/n * x * x';
 
[U, ~] = svd(R);
Us = U(:,1:P);

Us1 = J1*Us;
Us2 = J2*Us;

Psi = Us1\Us2;
Phi = eig(Psi);

DOA = asin( angle(Phi)/((M-m)*pi) ) * 180/pi;
% DOA = asin( angle(Phi)/((M-m)*pi) ) ;
DOA = sort(DOA);

end



