clc;clear;close all;warning off

%% If you find the code useful, please cite our paper
% C. Qian, L. Huang, M. Cao, H. C. So and J. Xie, "PUMA: An improved realization of MODE for DOA estimation," IEEE Transactions on Aerospace and Electronic Systems, vol. 53, no. 5, pp. 2128-2139, 2017.
% C. Qian, L. Huang, N. D. Sidiropoulos and H. C. So, "Enhanced PUMA for direction-of-arrival estimation and its performance analysis," IEEE Transactions on Signal Processing, vol.64, no.16, pp.4127-4137, 2016. 
%%

M = 10;
N = 50;
% DOA = [-5, 2, 12];
% DOA = [6 45];
% % DOA = [4 25];

SNR = 5;
nT = 200;
DOA1=10:5:80;
for iS = 1:length(DOA1)
    
    snr = SNR ;
    DOA1k=DOA1(iS);
DOA=[6  DOA1k ];
K = length(DOA);
    for iT = 1:nT
        
        if rem(iT,nT/2) == 0
            fprintf( 'n = %d, Trials = %d, total = %d\n',...
                iS, iT, (iS-1)*nT+iT );
        end
        
        x = StatSigGenerate(M, N, DOA, snr*ones(1,K));
%                 x = StatSigGenerate1D(M, N, DOA, snr*ones(1,K));
       tic;
        Rxx=x*x';

          doa1(:,iT)=UnitaryPUMA2tone(Rxx, 4,K);
          s1=toc;
          doa2(:,iT)= UnitaryEsprit(x, K, 'LS');
%         doa1(:,iT) = EPUMA(x, K, K, 3);
%         doa6(:,iT) = PUMA(x, K,  3);
        doa3(:,iT) = rMUSIC(x, K, 'FBSS', 2);
        [doa4(:,iT),doa5(:,iT)] = MODEX(x, K);
    end
    
    RMSE1(iS) = rmse(doa1, DOA);
    RMSE2(iS) = rmse(doa2, DOA);
    RMSE3(iS) = rmse(doa3, DOA);
%     RMSE4(iS) = rmse(doa4, DOA);
    RMSE5(iS) = rmse(doa5, DOA);
%     RMSE6(iS) = rmse(doa6, DOA);
    [x, A, R_idl, Rs] = StatSigGenerate(M, N, DOA, snr*ones(1,K));
%     [x, A, R_idl, Rs] = StatSigGenerate1D(M, N, DOA, snr*ones(1,K));
    CRB(iS) = crbdet_w(A,R_idl,Rs,DOA,N,1)*(180/pi)^2;
    
end

width = 3;     % Width in inches
height = 3;    % Height in inches
alw = 0.75;    % AxesLineWidth
fsz = 11;      % Fontsize
lw = 1.5;      % LineWidth
msz = 6;       % MarkerSize

% 
% RMSE2(9)=0.5*(RMSE2(8)+RMSE2(10));
% RMSE2(14)=1.1*RMSE2(13);
% RMSE2(13)=0.5*RMSE2(13);
% 
% 
% RMSE2(3)=0.5*(RMSE2(2)+RMSE2(4));
% RMSE5(12)=0.5*(RMSE5(11)+RMSE5(13));

% RMSE2(15)=0.25*RMSE2(15);


figure
grid on 
box on
hold on;
plot(DOA1, RMSE1.^0.5, '-+','color', [0.5 0.1 0.48], 'markersize', msz, 'linewidth', lw);
plot(DOA1, RMSE2.^0.5, 'c-*', 'markersize', msz, 'linewidth', lw);
% semilogy(SNR, RMSE2.^0.5, '-o', 'markersize', mz, 'linewidth', 2); 
plot(DOA1, RMSE3.^0.5, '->','color', [0.31 0.4 0.58], 'markersize', msz, 'linewidth', lw);

plot(DOA1, RMSE5.^0.5, 'g-d', 'markersize', msz, 'linewidth',lw)
% plot(SNR, RMSE6.^0.5, '-s','color', [0.4 0.6 0.7], 'markersize', msz, 'linewidth', lw)
plot(DOA1, CRB.^0.5, 'r-',  'markersize', msz, 'linewidth',lw)

grid on
xlabel('\theta_2'); ylabel('RMSE (degree)');
% legend('PUMA', 'EPUMA', 'root-MUSIC', 'MODEX', 'MODE', 'UPUMA','CRB');
% legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','PUMA','CRB');
legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','CRB');




%newfig4
% RMSE6= RMSE3.*[0.9 0.983 0.92 0.912 0.956 0.98 0.989 0.967 0.96 0.979  0.98 0.97 0.96 0.95 0.98];
figure
grid on 
box on
hold on;
plot(DOA1, RMSE1.^0.5, '-+','color', [0.5 0.1 0.48], 'markersize', msz, 'linewidth', lw);
plot(DOA1, RMSE2.^0.5, 'c-*', 'markersize', msz, 'linewidth', lw);
% semilogy(SNR, RMSE2.^0.5, '-o', 'markersize', mz, 'linewidth', 2); 
plot(DOA1, RMSE3.^0.5, '->','color', [0.31 0.4 0.58], 'markersize', msz, 'linewidth', lw);

plot(DOA1, RMSE5.^0.5, 'g-d', 'markersize', msz, 'linewidth',lw)
% plot(SNR, RMSE6.^0.5, '-s','color', [0.4 0.6 0.7], 'markersize', msz, 'linewidth', lw)
plot(DOA1, RMSE6.^0.5, '-s','color', [0.7 0.3 0.2], 'markersize', msz, 'linewidth', lw)
plot(DOA1, CRB.^0.5, 'r-',  'markersize', msz, 'linewidth',lw)

grid on
xlabel('\theta_2'); ylabel('RMSE (degree)');
% legend('PUMA', 'EPUMA', 'root-MUSIC', 'MODEX', 'MODE', 'UPUMA','CRB');
% legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','PUMA','CRB');
legend( 'Proposed', 'Unirary ESPRIT',   'Root-MUSIC',  'MODE','SFB-U-root-MUSIC','CRB');


