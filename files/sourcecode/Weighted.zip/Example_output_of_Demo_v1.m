% Will create a file : demo_data_YaleB_32x32.mat (around 2MB) in the current folder
% For demo purpose, we use the YaleB dataset with 32x32-sized images, which is publicly available here:  http://www.cad.zju.edu.cn/home/dengcai/Data/YaleB/YaleB_32x32.mat 
% --------------------------------------------------------
% 
% ans =
% 
% C:\Users\Jerry\Dropbox\MyProjects\Submissions\ECCV\VideoFaceClustering\code_release\demo_data_YaleB_32x32.mat
% 
% X is a d x n matrix, here d = 1024 and n = 640 
% Y is a n x 1 vector, here n = 640 
% ----------------- there are 10 classes -----------------
% No.   1 ~  64 samples (64 in total) are from the No. 1 class 
% No.  65 ~ 128 samples (64 in total) are from the No. 2 class 
% No. 129 ~ 192 samples (64 in total) are from the No. 3 class 
% No. 193 ~ 256 samples (64 in total) are from the No. 4 class 
% No. 257 ~ 320 samples (64 in total) are from the No. 5 class 
% No. 321 ~ 384 samples (64 in total) are from the No. 6 class 
% No. 385 ~ 448 samples (64 in total) are from the No. 7 class 
% No. 449 ~ 512 samples (64 in total) are from the No. 8 class 
% No. 513 ~ 576 samples (64 in total) are from the No. 9 class 
% No. 577 ~ 640 samples (64 in total) are from the No. 10 class 
% --------------------------------------------------------
% For demo purpose,
% let us divide the samples from each class into 4 groups with the same size 
% so we have 40 groups in total, and the number of samples in all groups are as follows 
% 
% G_length =
% 
%   Columns 1 through 21
% 
%     16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16
% 
%   Columns 22 through 40
% 
%     16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16    16
% 
% --------------------------------------------------------
% 
% 
% --------------------------------------------------------
% compute SVD of X_transpose*X , save in XtransX_SVD
% --------------------------------------------------------
% 
% XtransX_SVD = 
% 
%     sigma: [1x640 single]
%         V: [640x640 single]
% 
% running WBSLRR with time of each iteraion shown...
% 
% | Iter No.   1 || | G cost 0.034 | W cost 0.022| J cost 0.127| P cost 0.044
% | Iter No.   2 || | G cost 0.015 | W cost 0.033| J cost 0.078| P cost 0.048
% | Iter No.   3 || | G cost 0.018 | W cost 0.037| J cost 0.100| P cost 0.044
% | Iter No.   4 || | G cost 0.020 | W cost 0.028| J cost 0.083| P cost 0.041
% | Iter No.   5 || | G cost 0.021 | W cost 0.036| J cost 0.093| P cost 0.047
% | Iter No.   6 || | G cost 0.019 | W cost 0.028| J cost 0.111| P cost 0.043
% | Iter No.   7 || | G cost 0.020 | W cost 0.033| J cost 0.097| P cost 0.042
% | Iter No.   8 || | G cost 0.018 | W cost 0.030| J cost 0.103| P cost 0.047
% | Iter No.   9 || | G cost 0.022 | W cost 0.030| J cost 0.079| P cost 0.045
% | Iter No.  10 || | G cost 0.022 | W cost 0.029| J cost 0.091| P cost 0.045
% | Iter No.  11 || | G cost 0.021 | W cost 0.037| J cost 0.098| P cost 0.047
% | Iter No.  12 || | G cost 0.018 | W cost 0.027| J cost 0.077| P cost 0.047
% | Iter No.  13 || | G cost 0.019 | W cost 0.037| J cost 0.082| P cost 0.048
% | Iter No.  14 || | G cost 0.019 | W cost 0.035| J cost 0.102| P cost 0.045
% | Iter No.  15 || | G cost 0.022 | W cost 0.034| J cost 0.078| P cost 0.046
% | Iter No.  16 || | G cost 0.024 | W cost 0.030| J cost 0.092| P cost 0.048
% | Iter No.  17 || | G cost 0.018 | W cost 0.028| J cost 0.088| P cost 0.047
% | Iter No.  18 || | G cost 0.017 | W cost 0.038| J cost 0.086| P cost 0.042
% | Iter No.  19 || | G cost 0.023 | W cost 0.032| J cost 0.099| P cost 0.041
% | Iter No.  20 || | G cost 0.021 | W cost 0.029| J cost 0.101| P cost 0.046
% | Iter No.  21 || | G cost 0.020 | W cost 0.037| J cost 0.088| P cost 0.040
% | Iter No.  22 || | G cost 0.030 | W cost 0.035| J cost 0.082| P cost 0.076
% | Iter No.  23 || | G cost 0.033 | W cost 0.040| J cost 0.105| P cost 0.047
% | Iter No.  24 || | G cost 0.020 | W cost 0.034| J cost 0.124| P cost 0.047
% | Iter No.  25 || | G cost 0.019 | W cost 0.027| J cost 0.093| P cost 0.048
% | Iter No.  26 || | G cost 0.016 | W cost 0.036| J cost 0.080| P cost 0.046
% | Iter No.  27 || | G cost 0.018 | W cost 0.036| J cost 0.095| P cost 0.049
% | Iter No.  28 || | G cost 0.021 | W cost 0.036| J cost 0.092| P cost 0.045
% | Iter No.  29 || | G cost 0.018 | W cost 0.036| J cost 0.109| P cost 0.047
% | Iter No.  30 || | G cost 0.018 | W cost 0.028| J cost 0.077| P cost 0.047
% | Iter No.  31 || | G cost 0.017 | W cost 0.027| J cost 0.110| P cost 0.047
% | Iter No.  32 || | G cost 0.019 | W cost 0.031| J cost 0.120| P cost 0.043
% | Iter No.  33 || | G cost 0.020 | W cost 0.037| J cost 0.102| P cost 0.046
% | Iter No.  34 || | G cost 0.023 | W cost 0.035| J cost 0.084| P cost 0.048
% | Iter No.  35 || | G cost 0.024 | W cost 0.039| J cost 0.109| P cost 0.047
% | Iter No.  36 || | G cost 0.023 | W cost 0.029| J cost 0.098| P cost 0.040
% | Iter No.  37 || | G cost 0.022 | W cost 0.028| J cost 0.090| P cost 0.047
% | Iter No.  38 || | G cost 0.021 | W cost 0.036| J cost 0.091| P cost 0.047
% | Iter No.  39 || | G cost 0.020 | W cost 0.027| J cost 0.081| P cost 0.045
% | Iter No.  40 || | G cost 0.019 | W cost 0.037| J cost 0.090| P cost 0.056
% | Iter No.  41 || | G cost 0.025 | W cost 0.032| J cost 0.081| P cost 0.046
% | Iter No.  42 || | G cost 0.018 | W cost 0.030| J cost 0.099| P cost 0.041
% | Iter No.  43 || | G cost 0.018 | W cost 0.026| J cost 0.077| P cost 0.042
% | Iter No.  44 || | G cost 0.020 | W cost 0.036| J cost 0.099| P cost 0.046
% | Iter No.  45 || | G cost 0.022 | W cost 0.027| J cost 0.103| P cost 0.050
% | Iter No.  46 || | G cost 0.022 | W cost 0.036| J cost 0.077| P cost 0.046
% | Iter No.  47 || | G cost 0.021 | W cost 0.039| J cost 0.098| P cost 0.045
% | Iter No.  48 || | G cost 0.020 | W cost 0.028| J cost 0.096| P cost 0.047
% | Iter No.  49 || | G cost 0.020 | W cost 0.034| J cost 0.092| P cost 0.038
% | Iter No.  50 || | G cost 0.017 | W cost 0.036| J cost 0.087| P cost 0.047
% | Iter No.  51 || | G cost 0.020 | W cost 0.036| J cost 0.084| P cost 0.042
% | Iter No.  52 || | G cost 0.017 | W cost 0.027| J cost 0.086| P cost 0.042
% | Iter No.  53 || | G cost 0.019 | W cost 0.029| J cost 0.082| P cost 0.047
% | Iter No.  54 || | G cost 0.021 | W cost 0.036| J cost 0.092| P cost 0.042
% | Iter No.  55 || | G cost 0.019 | W cost 0.028| J cost 0.090| P cost 0.048
% | Iter No.  56 || | G cost 0.020 | W cost 0.036| J cost 0.108| P cost 0.043
% | Iter No.  57 || | G cost 0.021 | W cost 0.030| J cost 0.100| P cost 0.047
% | Iter No.  58 || | G cost 0.019 | W cost 0.028| J cost 0.088| P cost 0.044
% | Iter No.  59 || | G cost 0.023 | W cost 0.026| J cost 0.091| P cost 0.043
% | Iter No.  60 || | G cost 0.022 | W cost 0.036| J cost 0.084| P cost 0.041
% 
%  =====================  ^_^  converge ~~~ 
% 
% 
%  If you wish to record the total running  time,  set silent to true as folows: 
% running WBSLRR silently...
% 
% 
% info = 
% 
%            tictoc: 11.7482
%     tictoc_readme: 'info.tictoc is NOT meaningful unless you set silent to true'
%           cputime: 47.5179
%              iter: 60
% 
