% Cheng Qian, Harbin Institute of Technology.
% Data: Feb.26, 2015
%
% Free to use. Please cite our paper:
%
% C. Qian, L. Huang and H. C. So, �Computationally efficient ESPRIT algorithm 
% for direction-of-arrival estimation based on Nystrom method,� Signal Processing, 
% vol. 94, pp. 74�80, Jan. 2014.
%
% if the code is used in publications.
%--------------------------------------------------------------

function DOA = Nystrom_ESPRIT(x, m, P, k)
% Input:
% x is the sample matrix
% P is the number of sources
% m is the size of subarray
% k is the user-defined parameter, P <= k <= min(M,N)

M = size(x,1);

J1 = [eye(m), zeros(m,M-m)];
J2 = [zeros(m,M-m), eye(m)];

U2 = RKSSE(x, k);

Us1 = J1*U2(:,1:P);
Us2 = J2*U2(:,1:P);

Psi = Us1\Us2;
Phi = eig(Psi);

DOA = asin( angle(Phi)/((M-m)*pi) ) * 180/pi;
DOA = sort(DOA);

end


%------------nystrom method----------
function [Us2] = RKSSE(x, k)

Y = x(1:k, :); 
Z = x(k+1:end,:); 

R11 = Y*Y';  
R21 = Z*Y';

F = [R11; R21]*R11^(-1/2);

[Uf, ~] = svd(F'*F);

Us2 = F * Uf;

end
