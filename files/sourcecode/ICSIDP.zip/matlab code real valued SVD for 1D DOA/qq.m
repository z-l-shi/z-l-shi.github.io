function p=qq(N)
k=fix(N/2);
I=eye(k);
II=fliplr(I);
if mod(N,2)==0
    p=[I,j*I;II,-j*II]/sqrt(2);
else
    p=[I,zeros(k,1),j*I;zeros(1,k),sqrt(2),zeros(1,k);II,zeros(k,1),-j*II]/sqrt(2);
end




% k = fix(M/2);
% 
% if k*2 == M           % K : even
%     
%     Ik = eye(k); Jk=fliplr(Ik);
%     Qn = [Ik, 1j*Ik; Jk, -1j*Jk]/sqrt(2);
%     
%     kk=k-1; Ikk=eye(kk); Jkk=fliplr(Ikk); Zr=zeros(kk,1);
%     Qn1 = [Ikk, Zr, 1j*Ikk; Zr', sqrt(2), Zr'; Jkk, Zr, -1j*Jkk]/sqrt(2);
%     
% else                            % K : odd
%     
%     Ik=eye(k); Jk=fliplr(Ik); Zr=zeros(k,1);
%     Qn=[Ik, Zr, 1j*Ik; Zr', sqrt(2), Zr'; Jk, Zr, -1j*Jk]/sqrt(2);
%     Qn1=[Ik, 1j*Ik; Jk, -1j*Jk]/sqrt(2);
%     
% end