% function Demo_v1
clear; clc; close all;

fprintf('Will create a file : demo_data_YaleB_32x32.mat (around 2MB) in the current folder\n')
fprintf('For demo purpose, we use the YaleB dataset with 32x32-sized images, which is publicly available here:  http://www.cad.zju.edu.cn/home/dengcai/Data/YaleB/YaleB_32x32.mat \n')
fprintf('--------------------------------------------------------\n');
demo_data_local = 'demo_data_YaleB_32x32.mat';
if ~exist(demo_data_local,'file')
    demo_data_URL  =  'http://www.cad.zju.edu.cn/home/dengcai/Data/YaleB/YaleB_32x32.mat';
    urlwrite(demo_data_URL,demo_data_local)
end
data = load( demo_data_local );
% data = 
% 
%     fea: [2414x1024 double]
%     gnd: [2414x1 double]
ind  = (data.gnd<=10);
X    = data.fea( ind , :)';
fprintf('X is a d x n matrix, here d = %d and n = %d \n', size(X,1), size(X,2) )
Y    = data.gnd( ind , :);
fprintf('Y is a n x 1 vector, here n = %d \n', size(Y,1) )
clear ind;

pause(2);

n_divide = 4;
n_class = length( unique( Y ) );
fprintf('----------------- there are %d classes -----------------\n', n_class);
for which = 1 : n_class
    ind = find( Y == which );
    fprintf('No. %3d ~ %3d samples (%2d in total) are from the No. %d class \n',...
        min(ind), max(ind), length(ind), which );
end

pause(4);

fprintf('--------------------------------------------------------\n');
fprintf('For demo purpose,\nlet us divide the samples from each class into %d groups with the same size \n', n_divide);
fprintf('so we have %d groups in total, and the number of samples in all groups are as follows \n',n_divide*n_class);
G_length = repmat( 64/n_divide, 1, n_divide*n_class)
fprintf('--------------------------------------------------------\n');

pause(4);

fprintf('\n\n--------------------------------------------------------\ncompute SVD of X_transpose*X , save in XtransX_SVD\n--------------------------------------------------------\n');
    [~,S,V] = svd(X,'econ');
    clear XtransX_SVD;
    XtransX_SVD.sigma = diag( S ).^2;
    XtransX_SVD.sigma = XtransX_SVD.sigma';
    XtransX_SVD.sigma = single( XtransX_SVD.sigma );
    XtransX_SVD.V     = V;
    XtransX_SVD.V     = single( XtransX_SVD.V );
    XtransX_SVD
pause(2);    
% paras for demo
Rho_Start                    = 0.5;
Rho_Factor                 = 1.2;
Rho_Max                     = 1e6;
Converge_Thre          = 1e-4;
EstRank                       = 100;
Total_Round               = 200;
%====================================== para
para.EstRank  = EstRank;%~~~
para.G_length = G_length;%~~~
%~~~ For simplicity, here we jsut show the  inner-track only case. namely setting 1 in our paper, as an example.%
%~~~ so Q is calculated as follows:
Q            = 1./sqrt(G_length' * G_length);%  Qij = 1/sqrt(n_i * n_j)
para.Q    = Q;
para.Total_Round = Total_Round;%~~~
%====================================== other_para
other_para.rho                             = Rho_Start;
other_para.rho_factor                 = Rho_Factor;
other_para.rho_max                    = Rho_Max;
other_para.converge_threshold = Converge_Thre;
%====================================== run WBSLRR
% just for demo
lmd_for_demo        = 1e-3;
gamma_for_demo = 5e-3;

para.lambda    = lmd_for_demo;%~~~
para.gamma    = gamma_for_demo;%~~~

fprintf('running WBSLRR with time of each iteraion shown...\n\n');
silent = 1;
[ W, G, P, J, info] = WBSLRR_ECCV_v1( XtransX_SVD, para, other_para, silent);

%try also :
fprintf('\n\n If you wish to record the total running  time,  set silent to true as folows: \n')
fprintf('running WBSLRR silently...\n\n');

silent = true;
[ W, G, P, J, info] = WBSLRR_ECCV_v1( XtransX_SVD, para, other_para, silent);
info


Z    = G * W;

close all;
h_fig = figure;
imshow( Z,[] )
title('Z= G * W')
        
     

 
    
     