function [hatmu ] = UnitaryPUMA(XX, max_iter)
[M0, N0] = size(XX);


II1=fliplr(eye(M0));
II2=fliplr(eye(N0));
AA1=[XX II1*conj(XX)*II2];
XXreal=qq(M0)'*AA1*qq(2*N0);
[up,sp,vp] = svd(XXreal);
emu1=up(:,1);

Jmu1=eye(M0-1,M0);
Jmu2=flipud(fliplr(Jmu1));

TJT=qq(M0-1)'*Jmu2*qq(M0);
Kmu1=real(TJT);
Kmu2=imag(TJT);
xmu1=Kmu1*emu1;
xmu2=Kmu2*emu1;

hatamu0=pinv(xmu1)*xmu2;
hatAmu=Kmu2-hatamu0*Kmu1;
Wmu=hatAmu*hatAmu.';

% hatmu=2*atan(real(xmu1.'*inv(Wmu)*xmu2./(xmu1.'*inv(Wmu)*xmu1)))
%%%
amuinit=hatamu0;
max_iter=5;
for iter = 1:max_iter
Amu=Kmu2-amuinit*Kmu1;
Wmu=Amu*Amu';
amu=(xmu1' * inv(Wmu) * xmu2) ./(xmu1' * inv(Wmu) * xmu1);
amuinit=amu;
end
hatmuleft=2*atan(real(amuinit));

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%second dimen/right 
% XX1=XX.';
% AA11=[XX1 II1*conj(XX1)*II2];
% XXreal1=qq(M0)'*AA11*qq(2*N0);
% [up1,sp1,vp1] = svd(XXreal1);
% emu11=up(:,2);
% 
% Jmu11=eye(N0-1,N0);
% Jmu21=flipud(fliplr(Jmu11));
% 
% TJT1=qq(N0-1)'*Jmu21*qq(N0);
% Kmu11=real(TJT1);
% Kmu21=imag(TJT1);
% xmu11=Kmu11*emu11;
% xmu21=Kmu21*emu11;
% 
% hatamu01=pinv(xmu11)*xmu21;
% hatAmu1=Kmu21-hatamu01*Kmu11;
% Wmu1=hatAmu1*hatAmu1.';
% 
% % hatmu=2*atan(real(xmu1.'*inv(Wmu)*xmu2./(xmu1.'*inv(Wmu)*xmu1)))
% %%%
% amuinit1=hatamu01;
% % max_iter=5;
% for iter = 1:max_iter
% Amu1=Kmu2-amuinit1*Kmu11;
% Wmu1=Amu1*Amu1';
% amu1=(xmu11' * inv(Wmu1) * xmu21) ./(xmu11' * inv(Wmu1) * xmu11);
% amuinit1=amu1;
% end
% hatmuright=2*atan(real(amuinit1));
% 
% m = -round(N0/2-0.1):1:round(N0/2-0.1);
% hatmuright = (hatmuright+m*2*pi)/N0;
% [val, idx] = min(abs(hatmuright - hatmuleft));
% hatmuright = hatmuright(idx);




% hatmu = ((M0^2-1)*hatmuleft+M0^2*(N0^2-1)*hatmuright)/((M0^2-1)+M0^2*(N0^2-1));
hatmu =hatmuleft;
% hatmu =[hatmuleft hatmuright];
