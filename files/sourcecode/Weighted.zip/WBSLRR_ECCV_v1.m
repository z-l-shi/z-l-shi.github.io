function [ W, G, P, J, info] = WBSLRR_ECCV_v1( XtransX_SVD, para, other_para, silent)
%================== Solve the folowing prob: ========================================
%   min_{ Z }   NulcearNorm(Z)  +   gamma *  sum_{i,j} Qij* ||Z^(i.j)||_F + lambda/2* || X - XZ ||_F^2       (i.e., (6) in [1]) .
%             |
%             |  introduce P and J,  factorize Z as G*W
%            V
%--------------------------------------------------------------------------
%   min_{ G'G=I,W,P,J }   
%      NulcearNorm(W)    +  1/gamma          * sum_{i,j} Qij* ||Z^(i.j)||_F^2  +  lambda/(2*gamma) * || X - XZ ||_F^2    (i.e., (7) in [1]) .
%             s.t.  I-GW=P,          J=P.
%--------------------------------------------------------------------------
%            ||   Augmented Lagrange Function
%            V
%   Lag{ G,W,P,J } 
%                   =  NulcearNorm(Z)  
%                       +  gamma         *  sum_{i,j} Qij* ||Z^(i.j)||_F 
%                       +  lambda/2      *  || X - XZ ||_F^2.
%                       +  rho/2             *  [                      || I-GW-P+LagMul_L/rho ||_F^2  +  || J-P+LagMul_Lmd/rho ||_F^2           ]
%                       + Constant
% where
%                   Constant = -  1/(2*rho)        *  [    || LagMul_L ||_F^2   +  || LagMul_Lmd ||_F^2    ].

%================== Input  XtransX_SVD, para, other_para, silent  ( 4 inputs ) ========================================

% XtransX    | struct or a matrix form of X'*X   |   i.e., XtransX_SVD = X'X = V * diag(sigma) * V'
%           .sigma      | rank(X) x 1  |  singular values of  X'X 
%           .V             | n  x rank(X)  | those singular vectors

% para | struct |
%      .lambda           |  scalar  |  see the problem
%      .gamma           |  scalar  |  see the problem
%      .Q                     |  m x m  |  see the problem
%      .EstRank          |  scalar  |  estimated max rank of Z  | 
%                                In [1], considering the size n=17337(BF0502) and n=4660 (for Notting Hill), EstRank is empirically set to 1000, as mentioned in the paragraph above (7).
%      .G_length         |  1 x  m  |  length of each track, namely  [ n_1, n_2, ...,  n_m ]     |  (correspondingly, make sure that X = [X^1,...,X^m]).
%      .Total_Round   |  scalar  | max number of iterations.

%other_para | struct  | the following fileds are all scalars:
%      .rho                                 | rho_0 in Algorithm 1 in [1].
%      .rho_factor                     | (1+delta_rho) in Algorithm 1 in [1].
%      .rho_max                        | rho_max in Algorithm 1 in [1].
%      .converge_threshold     | epsilon in Algorithm 1 in [1].
%      .fun_handle_for_alpha 

% silent | logical or double |  show info of the iteraions
%          if set to false,              show info every 10 iter
%          if set to true,                do NOT show info
%          if set to a number k ,   show infn every k iter

%================== Output {W, G, P ,J, info}   ( 5 output )  ========================================
% W  | see the prob
% G  | see the prob
% P  | see the prob
% J  | see the prob
% info | info during optimiztion
%           tictoc:           the time recored using tic toc
%           tictoc_readme:    a gentle reminder:  'info.tictoc is NOT meaningful unless you set silent to true'
%           cputime:          the time recored using cputime
%           iter:             the number of iterations, usually depends on the parameters.

%================= Please kindly cite the following paper if you use the code in your publication =======================
%[1] Shijie Xiao, Mingkui Tan, Dong Xu, "Weighted Block-Sparse Low Rank Representation for Face Clustering in Videos", European Conference on Computer Vision (ECCV), pp. 123-138, 2014
% 
% @inproceedings{Xiao2014WBSLRR,
%   author    = {Shijie Xiao and
%                Mingkui Tan and
%                Dong Xu},
%   title     = {Weighted Block-Sparse Low Rank Representation for Face Clustering
%                in Videos},
%   booktitle = {European Conference on Computer Vision},  
%   year      = {2014},
%   pages     = {123--138},
% }

%================= Do not hesitate to contact me (Mr. Shijie Xiao,  xiaoshijiehithonor@gmail.com) if you have any quations regarding this code. =======================
%================= This code is from the project page of [1]:     https://sites.google.com/site/xiaoshijiejerry/projec/eccv2014_wbslrr/
%================= This code is strictly for reseach purpose only.

%$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$   Timing Start  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
if silent
    tic
end
start_cputime  =  cputime;
%===============================  Check input and add path
if ~exist('other_para','var')
    other_para = [];
end
if ~exist('silent','var')
    silent = false;
end
silent_GENERAL = silent;
%================================   Make sure XtransX_SVD is a proper struct
if isstruct( XtransX_SVD )
    if isfield(XtransX_SVD,'sigma')&& isfield(XtransX_SVD,'V')
        if size( XtransX_SVD.sigma, 1 )>1
            XtransX_SVD.sigma = ( XtransX_SVD.sigma )';
        end
    else
        error('Make sure struct XtransX_SVD contains the 2 fields: sigma,V');
    end
else
    error('Please input XtransX_SVD as a struct which contains the 2 fields: sigma,V');
end
%================================   get parameters from para
% para | struct |
%      .lambda      | as in [1]
%      .gamma      | as in [1] 
%      .Q                |as in [1] 
%      .G_length   |  [ n_1, n_2, ...,  n_m ]     |    i.e., the number of faces in each track,  in the order of the face tracks ( X = [X^1,...,X^m]).
EstRank        = para.EstRank;
lambda          = para.lambda;
gamma          = para.gamma;
G_length       = para.G_length;
Q                    = para.Q;
Total_Round = para.Total_Round;
%================================   obtain paras form other_para
converge_threshold  = other_para.converge_threshold;
rho_factor                  = other_para.rho_factor;
rho                              = other_para.rho;
rho_max                     = other_para.rho_max;
%================================   Initialization
n_instance  = size( XtransX_SVD.V,1);

LagOne   = zeros( n_instance, n_instance,'single');
LagTwo   = zeros( n_instance, n_instance,'single');

P         = zeros( n_instance, n_instance,'single');
G         = zeros( n_instance, EstRank   ,'single');
W        = zeros( EstRank   , n_instance,'single');
%================================   for loop 
for iter_i = 1:Total_Round
    if islogical( silent_GENERAL )
        if ~silent_GENERAL
            silent = (rem( iter_i, 10)~=0) || (iter_i==1);
        end
    else
        silent = (   rem( iter_i, silent_GENERAL)~=0   );
        if silent_GENERAL ==1% if you would like to see the info of each iteration
            silent = false;
        end
    end
    %***************************************************************************************
    %%%   update G   %%%
    %%%   G = argmin_{ G'*G = I }      || (I-P+Lag/rho)   -   G*W    ||_F^2,   
    if ~silent
        fprintf('| Iter No.%4d |',iter_i);
        fprintf('|');
        tic;
    end
    
    temp   = ( eye(n_instance,'single')-P+( LagOne/rho ) )*( W' );
    G         =  subfun_procruste_given_M(  temp );
    clear temp;
    
    if ~silent
        time_temp = toc;
        fprintf(' | G cost %.3f',time_temp);
    end
    %***************************************************************************************
    %%%   update W   %%%
    %%%    W = argmin 1/rho ||  W  ||_* + 0.5 ||Z - temp||_F^2,         
    %%%   where
    %%%   temp = G'( I - P + LagOne/rho );
    if ~silent
        tic;
    end
    
    temp                 = (G')*(      eye(n_instance,'single') - P + ( LagOne/rho )     );
    SVT_thre_Z     = rho;
    THIS_silent      = true;
    [W ]   = subfun_update_Mlowrank( temp, SVT_thre_Z, THIS_silent);
    clear temp;
    
    if ~silent
        time_temp = toc;
        fprintf(' | W cost %.3f',time_temp);
    end
    %***************************************************************************************
    %%%   update J  %%%
    %%%   J        = argmin_{J}     || I - J  ||_G,Q + 0.5*( rho/gamma ) || J-P+LagMul_Lmd/rho ||_F^2 .
    %%%            ||   Jhat   = I-J
    %%%            V
    %%%   Jhat   = argmin_{Jhat}  ||  Jhat  ||_G,Q + 0.5*( rho/gamma ) || temp - Jhat ||_F^2 .
    %%%   temp = I-P+LagMul_Lmd/rho
    if ~silent
        tic
    end
    
    temp        = eye( n_instance,'single') - P + (LagTwo/rho);
    para_J     = rho/gamma;
    %this outputs is actually J_hat,  we name it J to avoid additional space consumption.
    [ J  ]          = subfun_solving_J_hat_using_cellfun( temp ,Q, G_length, para_J   );
    %J = I - Jhat.
    J               = eye( n_instance,'single') - J;
    clear temp J_hat;
    if ~silent
        time_temp  =  toc;
        fprintf('| J cost %.3f', time_temp);
    end
    %***************************************************************************************
    %%%   update P  %%%
    %%%   P    = argmin_{ P }     lambda/2 * tr(P'X'XP)  +   (2*rho)/2    ||   P - C ||_F^2 .
    %%%   where   C    =  0.5 * (   ...
    %%%                                          I - GW + J +    (LagMul_L+LagMul_Lmd) / rho   ...
    %%%                                     ) 
    %%%            || 
    %%%            V
    %%%   P = C  -   V * /\ * (  V'  *  C )                        i.e.,  (13) in [1].
    %%%   where    /\            = w*sigma ./ ( 1 + w*sigma );        
    %%%                 XtransX = V * diag( sigma) * V',   
    %%%                            w = lambda/( 2*rho);.
    if ~silent
        tic
    end
    I_min_GW =  eye( n_instance,'single')  - (G*W);
    C                 = 0.5*(  I_min_GW+J + (   (LagOne+LagTwo) / rho   )   );
    w                 = lambda/( 2*rho);
    [ P   ]           = subfun_updating_P_fast(   C,   w , XtransX_SVD  );
    
     clear C;
    if ~silent
        time_temp  =  toc;
        fprintf('| P cost %.3f\n', time_temp);
    end
    %***************************************************************************************
    %%%   update LagOne  %%
    %     I_min_Z_min_P  =  eye( n_instance ) - (P + Z ) ;
    %LagOne                = LagOne + rho*( I_min_Z_min_P  );
    %conv_val_one      = max(max( abs(I_min_Z_min_P)));
    I_min_GW           = I_min_GW - P;
    LagOne                = LagOne + rho*( I_min_GW  );
    conv_val_one      = max( max( abs(  I_min_GW     ))   );
    clear I_min_GW;
    
    J_min_P              = J - P;
    LagOne               = LagOne + rho*( J_min_P  );
    conv_val_two      = max( max( abs(  J_min_P     ))   );
    clear J_min_P;
    %***************************************************************************************
    %%%   update rho   %%
    rho      = min(  rho_factor * rho,  rho_max  );
    %***************************************************************************************
    %%%   check convergence %%
    conv_val    =  max(  conv_val_one, conv_val_two );
    if  conv_val<converge_threshold
        if ~silent
            fprintf('\n =====================  ^_^  converge ~~~ \n');
        end
        break;
    end
end
%$$$$$$$$$$$$$$$$$   Timing Stop  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
if silent
    info.tictoc                      = toc;
    info.tictoc_readme       = 'info.tictoc is NOT meaningful unless you set silent to true';
end
info.cputime   = cputime - start_cputime;

%$$$$$$$$$$$$$$$$$  #iter   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
info.iter           = iter_i;
end


function [ P   ]           = subfun_updating_P_fast(   C,   w , XtransX  )
% this functoin is to do:
%   P    = C  - ( XtransX_SVD.V * /\ )  * (   XtransX_SVD.V'  *  C );  
%   where       /\        = diag(temp) ,
%   in which    temp =  w *XtransX_SVD.sigma     ./      ( 1 + w* XtransX_SVD.sigma ); 
P = C - (    ...
                  bsxfun(  @times, ...
                                XtransX.V, ...
                                ( XtransX.sigma ./ ( XtransX.sigma +  1/w )  )  ...
                               )...
                  * (  ( XtransX.V') * C )    ...
              );
end

function [Jhat_opt]  = subfun_solving_J_hat_using_cellfun( temp ,Q, G_length, COEF )
% this functoin solves the  following prob:
%         Jhat_opt      = argmin_{Jhat}     Qij* ||Jhat^(i.j)||_F + 0.5*( COEF ) || temp - Jhat ||_F^2 .
Jhat_opt = cell2mat( ...
                                cellfun(  ...
                                            @L2_sqL2_threshold,...
                                            mat2cell(temp, G_length, G_length), ...
                                            num2cell(  (1/(  COEF  ))*Q  ),...
                                            'UniformOutput', false...
                                            ) ...
                                );
end

function  output =  L2_sqL2_threshold(   given_mat, thre  )
given_Fnorm = sqrt( sum(sum( given_mat.^2) )  );
if given_Fnorm > thre
    output = given_mat * (    (given_Fnorm -thre) / given_Fnorm   );
else
    output = zeros( size( given_mat ),'single' ); 
end
end

function G       =  subfun_procruste_given_M(  M )
% this function solves the Procruste problem
[U,~,V] = svd( M, 'econ');%do thin svd
G         = U*(V');
end
 
function [J ] = subfun_update_Mlowrank(X, mu, silent )
% this functoin solves the  following prob:
% J = argmin
%        || J ||_* + 0.5*mu*||J - ( X )||_F^2
if ~silent
    fprintf('sin val >  thre =%.3f NORMAL SVD', 1/mu );
end
[U,sigma,V] = svd(   X,'econ');

sigma  = diag(sigma)';
ind       = sigma>1/mu;

if  sum(ind)~=0
    sigma = sigma( ind )-1/mu;
    J         = bsxfun(@times, U(:,ind) , sigma(ind) ) * ( V(:,ind)') ;
else
    J = zeros( size( X ),'single');
end
end